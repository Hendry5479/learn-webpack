module.exports = {
  configureWebpack: {
    resolve: {
      alias: {
        
      }
    }
  }
}
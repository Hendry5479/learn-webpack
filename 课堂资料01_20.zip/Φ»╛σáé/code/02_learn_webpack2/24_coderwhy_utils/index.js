import * as math from './lib/math';
import * as format from './lib/format';

console.log("abc");

export {
  math,
  format
}


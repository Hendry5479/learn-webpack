// This file can update, because it accept itself.
// A dispose handler removes the old <style> element.

require("bundle!./style2.js");

module.exports = () => {
  return import(/* webpackChunkName: "chunkB" */ "./b");
};

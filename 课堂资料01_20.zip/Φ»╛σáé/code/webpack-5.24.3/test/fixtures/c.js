module.exports = function b() {
	require("./a");
	return "This is c";
};
var six = 6;
require("bundle!./items/item (" + six + ")");
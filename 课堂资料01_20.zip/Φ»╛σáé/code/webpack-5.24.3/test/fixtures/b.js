module.exports = function b() {
	return "This is b";
};

// Test CJS top-level return
return;

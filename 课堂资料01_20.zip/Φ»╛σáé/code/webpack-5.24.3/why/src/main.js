import { sum } from "./utils/math";

console.log(sum(20, 30));
console.log("Hello Webpack");

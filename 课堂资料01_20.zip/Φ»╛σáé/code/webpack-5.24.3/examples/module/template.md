# example.js

```javascript
_{{example.js}}_
```

# methods.js

```javascript
_{{methods.js}}_
```

# counter.js

```javascript
_{{counter.js}}_
```

# dist/output.js

```javascript
_{{dist/output.js}}_
```

# dist/output.js (production)

```javascript
_{{production:dist/output.js}}_
```

# Info

## Unoptimized

```
_{{stdout}}_
```

## Production mode

```
_{{production:stdout}}_
```

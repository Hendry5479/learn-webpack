module.exports = (loader, callback) => {
	callback(new Error("Loaders are not supported"));
};

const message: string = "Hello TypeScript";

const foo = (info: string) => {
  console.log(info);
}

foo("abc");

// const p = new Promise((resolve, reject) => {})

export {}

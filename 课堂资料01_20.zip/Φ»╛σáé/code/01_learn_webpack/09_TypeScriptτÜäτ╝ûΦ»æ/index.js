var message = "Hello TypeScript";
var foo = function (info) {
    console.log(info);
};
foo(message);

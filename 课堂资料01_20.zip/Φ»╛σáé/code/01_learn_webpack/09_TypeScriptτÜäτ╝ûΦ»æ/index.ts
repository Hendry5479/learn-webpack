const message: string = "Hello TypeScript";

const foo = (info: string) => {
  console.log(info);
}

foo(message);

export {}
